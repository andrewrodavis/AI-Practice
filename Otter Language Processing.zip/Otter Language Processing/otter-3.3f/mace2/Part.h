#ifndef TP_PART_H
#define TP_PART_H

struct list *variable_optimize(struct list *l, int part_vars);

#endif  /* ! TP_PART_H */
