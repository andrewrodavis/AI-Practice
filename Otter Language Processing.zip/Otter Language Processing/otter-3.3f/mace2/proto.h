/* proto.h made 
Tuesday, May 08, 03:21:59 PM 2001 (CDT)
*/

/* print.c */

void print_model(FILE *fp);
void print_model_portable(FILE *fp);
void print_model_ivy(FILE *fp);
