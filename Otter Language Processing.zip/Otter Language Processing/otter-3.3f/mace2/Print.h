#ifndef TP_PRINT_H
#define TP_PRINT_H

/* print.c */

void print_model(FILE *fp);
void print_model_portable(FILE *fp);
void print_model_ivy(FILE *fp);

#endif  /* ! TP_PRINT_H */
