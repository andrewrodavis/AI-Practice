package rushhour.afit.edu;

public class ImplementMySearch implements Search {
	
	private Board board;
	
	public ImplementMySearch(Board board) {
		this.board = board;
	}
	
	@Override
	public Move findMoves() {
		return null;
	}
	
	@Override
	public long nodeCount() {
		return 0;
	}
}
