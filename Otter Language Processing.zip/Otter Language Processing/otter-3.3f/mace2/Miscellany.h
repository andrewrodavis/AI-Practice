#ifndef TP_MISC_H
#define TP_MISC_H

/* function prototypes from misc.c */

void exit_with_message(int exit_code, int stats);
void MACE_abend(char *str);

#endif  /* ! TP_MISC_H */

